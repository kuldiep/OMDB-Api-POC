package com.android_poc.moviesfornoon.ui


import android.os.Bundle

import com.android_poc.moviesfornoon.R

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}
